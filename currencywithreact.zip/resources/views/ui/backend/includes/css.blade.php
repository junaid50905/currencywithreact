<link rel="stylesheet" href="{{ asset('ui/backend') }}/assets/vendors/feather/feather.css">
<link rel="stylesheet" href="{{ asset('ui/backend') }}/assets/vendors/mdi/css/materialdesignicons.min.css">
<link rel="stylesheet" href="{{ asset('ui/backend') }}/assets/vendors/ti-icons/css/themify-icons.css">
<link rel="stylesheet" href="{{ asset('ui/backend') }}/assets/vendors/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="{{ asset('ui/backend') }}/assets/vendors/typicons/typicons.css">
<link rel="stylesheet" href="{{ asset('ui/backend') }}/assets/vendors/simple-line-icons/css/simple-line-icons.css">
<link rel="stylesheet" href="{{ asset('ui/backend') }}/assets/vendors/css/vendor.bundle.base.css">
<link rel="stylesheet"
    href="{{ asset('ui/backend') }}/assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.css">
<!-- endinject -->
<!-- Plugin css for this page -->
<link rel="stylesheet" href="{{ asset('ui/backend') }}/assets/vendors/datatables.net-bs4/dataTables.bootstrap4.css">
<link rel="stylesheet" type="text/css" href="{{ asset('ui/backend') }}/assets/js/select.dataTables.min.css">
<!-- End plugin css for this page -->
<!-- inject:css -->
<link rel="stylesheet" href="{{ asset('ui/backend') }}/assets/css/style.css">
<!-- endinject -->
<link rel="shortcut icon" href="{{ asset('ui/backend') }}/assets/images/favicon.png" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
    integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
<link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet">

@yield('styles')
