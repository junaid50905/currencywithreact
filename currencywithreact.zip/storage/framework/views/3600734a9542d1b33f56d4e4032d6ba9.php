<?php $__env->startSection('title'); ?>
    Profit
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-panel'); ?>
    <div class="row">
        <div class="col-sm-9">
            <div class="card">
                <div class="card-body">
                    <!-- Button to trigger Add Modal -->
                    <button class="btn btn-primary btn-sm rounded" data-bs-toggle="modal" data-bs-target="#addModal">Add Profit</button>
                    <h4 class="card-title">Profits</h4>
                    <div class="table-responsive">
                        <!-- Profits Table -->
                        <table class="table mt-3">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Title</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $profits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($profit->title); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('profit.destroy', $profit->id)); ?>"
                                                    class="btn btn-sm btn-danger"
                                                    onclick="return confirm('Are you sure?')"><i
                                                        class="fa-solid fa-trash"></i></a>
                                            <a href="<?php echo e(route('profit.rates', $profit->id)); ?>"
                                                    class="btn btn-sm btn-success">
                                                    <i class="fa-regular fa-eye"></i>
                                                </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Modal -->
    <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="addModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addModalLabel">Add Profit</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?php echo e(route('profit.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="title" class="form-label">Title</label>
                            <input type="text" name="title" class="form-control" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success btn-sm">Add profit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('ui.backend.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\currencywithreact\resources\views/ui/backend/pages/profit/index.blade.php ENDPATH**/ ?>