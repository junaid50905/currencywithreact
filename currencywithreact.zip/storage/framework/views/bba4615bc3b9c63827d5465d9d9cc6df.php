<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('ui/frontend')); ?>/assets/css/style.css">
    <title>Slides show</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>

    

    <!-- Example Code -->
    <div id="carouselExampleInterval" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
            
            <div class="carousel-item bg-primary active" data-bs-interval="<?php echo e($exchange_rate_duration); ?>">
                <h1 class="text-danger text-center"
                    style="margin-top: 5vh; font-size: calc(20px + 3vw); margin-bottom: 5vh;">Foreign Currency
                    Exchange Rate
                </h1>
                <div class="table-responsive" style="margin: 0 10vw;">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Currency</th>
                                <th>Code</th>
                                <th>Buying (BDT)</th>
                                <th>Selling (BDT)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $exchange_rates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exchange_rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $currency = DB::table('currencies')->find($exchange_rate->currency_id);
                                ?>
                                <tr>
                                    <td><?php echo e($currency->symbol); ?> <?php echo e($currency->name); ?> <img class="currency_logo"
                                            src="<?php echo e($currency->flag); ?>" alt=""></td>
                                    <td><?php echo e($currency->code); ?></td>
                                    <td><?php echo e($exchange_rate->buying_rate); ?></td>
                                    <td><?php echo e($exchange_rate->selling_rate); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <?php $__currentLoopData = $profits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-item bg-primary" data-bs-interval="<?php echo e($profit_duration); ?>">
                    <h1 class="text-danger text-center"
                        style="margin-top: 5vh; font-size: calc(20px + 3vw); margin-bottom: 5vh;">
                        <?php echo e($profit->title); ?>

                    </h1>
                    <div class="table-responsive" style="margin: 0 10vw;">
                        <table class="table table-bordered table-striped">
                            <?php
                                $profit_rates = DB::table('profit_rates')
                                    ->where('profit_id', $profit->id)
                                    ->orderBy('id', 'asc')
                                    ->get();
                            ?>
                            <tbody>
                                <?php $__currentLoopData = $profit_rates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profit_rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($profit_rate->title ?? ''); ?></td>
                                        <td><?php echo e($profit_rate->rate ?? ''); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-item" data-bs-interval="<?php echo e($image->duration); ?>">
                    <img src="<?php echo e(asset('ui/uploads/image')); ?>/<?php echo e($image->image); ?>" class="d-block w-100">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-item" data-bs-interval="<?php echo e($video->duration); ?>">
                    <video class=" video-player" autoplay muted playsinline>
                        <source src="<?php echo e(asset('ui/uploads/video')); ?>/<?php echo e($video->video); ?>" type="video/mp4">
                    </video>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
    </div>

    <!-- JavaScript to reset video to the start when it becomes active -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var carousel = document.getElementById('carouselExampleInterval');
            carousel.addEventListener('slid.bs.carousel', function(event) {
                var activeItem = event.relatedTarget; // Get the new active carousel item
                var video = activeItem.querySelector('video');

                if (video) {
                    // Pause and reset the video, then play it from the start
                    video.pause();
                    video.currentTime = 0;
                    video.play();
                }
            });
        });
    </script>

    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var carousel = document.getElementById('carouselExampleInterval');
            var totalItems = document.querySelectorAll('.carousel-item').length;

            carousel.addEventListener('slid.bs.carousel', function(event) {
                var activeIndex = event.to; // Get the index of the new active carousel item
                var video = event.relatedTarget.querySelector('video');

                // If it's a video, pause and reset it to play from the start
                if (video) {
                    video.pause();
                    video.currentTime = 0;
                    video.play();
                }

                // If the last item is reached, refresh the page
                if (activeIndex === totalItems - 1) {
                    setTimeout(function() {
                        location.reload();
                    }, event.relatedTarget.dataset.bsInterval); // Refresh after the slide interval
                }
            });
        });
    </script>


</body>

</html>
<?php /**PATH C:\laragon\www\currencywithreact\resources\views/ui/frontend/welcome.blade.php ENDPATH**/ ?>