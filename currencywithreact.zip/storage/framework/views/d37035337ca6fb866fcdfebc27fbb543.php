<?php $__env->startSection('title'); ?>
    Contents
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <style>
        .table td img {
            width: 150px;
            height: 100px;
            border-radius: 0;
            object-fit: cover;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-panel'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <a href="<?php echo e(route('create_new_content')); ?>" class="btn btn-sm btn-primary mb-2"><span class="mdi mdi-server-plus"></span> Create new content</a>
                    <h4 class="card-title">Contents</h4>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Content Type</th>
                                    <th>File</th>
                                    <th>Duration</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td class="text-capitalize"><?php echo e($content->type); ?></td>
                                        <?php if($content->type == 'image'): ?>
                                            <td><img src="<?php echo e($content->image); ?>"
                                                    alt=""></td>
                                        <?php elseif($content->type == 'video'): ?>
                                            <td>
                                                <video height="100" width="150" controls>
                                                    <source src="<?php echo e($content->video); ?>" type="video/mp4">
                                                </video>
                                            </td>
                                        <?php else: ?>
                                            <td></td>
                                        <?php endif; ?>
                                        <td><?php echo e($content->duration / 1000); ?> Seconds</td>
                                        <td>
                                            <div>
                                                <form action="<?php echo e(route('content.destroy', $content->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <button onclick="return confirm('Are you sure?')" type="submit"
                                                        class="btn btn-sm text-danger"><i
                                                            class="menu-icon mdi mdi-delete-circle-outline"
                                                            style="font-size: 30px;"></i></button>
                                                </form>
                                            </div>
                                            <div>
                                                <?php if($content->type != 'video'): ?>
                                                    <i class="mdi mdi-clock-edit-outline text-warning ms-3"
                                                        data-bs-toggle="modal"
                                                        data-bs-target="#exampleModal-<?php echo e($content->id); ?>"
                                                        style="font-size: 30px; cursor: pointer;"></i>
                                                <?php endif; ?>
                                            </div>

                                        </td>

                                        
                                        <div class="modal fade" id="exampleModal-<?php echo e($content->id); ?>" tabindex="-1"
                                            aria-labelledby="exampleModal-<?php echo e($content->id); ?>Label" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModal-<?php echo e($content->id); ?>Label">
                                                            Update content duration</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form action="<?php echo e(route('content.update_duration', $content->id)); ?>"
                                                            method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="form-group">
                                                                <label>Duration</label>
                                                                <input type="number"
                                                                    value="<?php echo e($content->duration / 1000); ?>" name="duration"
                                                                    class="form-control">
                                                                <small class="text-muted">Write only number of seconds (Eg:
                                                                    30)</small>
                                                            </div>
                                                            <button type="submit" class="btn btn-success">Update</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('ui.backend.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\currencywithreact\resources\views/ui/backend/pages/content.blade.php ENDPATH**/ ?>