<?php $__env->startSection('title'); ?>
    <?php echo e($profit->title); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-panel'); ?>



    <div class="row">
        <div class="col-sm-7">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title"><?php echo e($profit->title); ?></h4>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Title</th>
                                    <th>Rate</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $profit_rates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profit_rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($profit_rate->title); ?></td>
                                    <td><?php echo e($profit_rate->rate); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('profit_rate.destroy', [$profit->id, $profit_rate->id])); ?>"
                                                    class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">
                                                    <i class="fa-solid fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Add or Edit form -->
        <div class="col-sm-5">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Add new</h4>
                            <hr>
                            <form action="<?php echo e(route('add.profit_rate', $profit->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label>Title</label>
                                    <input type="text" name="title" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label>Rate</label>
                                    <input type="text" name="rate" class="form-control" required>
                                </div>
                                <button class="btn btn-sm btn-success w-100" type="submit">Add</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('ui.backend.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\currencywithreact\resources\views/ui/backend/pages/profit_rate/index.blade.php ENDPATH**/ ?>