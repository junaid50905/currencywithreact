<?php $__env->startSection('title'); ?>
    Exchange rate
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <style>
        .table td img {
            width: 30px;
            height: 30px;
            object-fit: cover;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-panel'); ?>



    <div class="row">
        <div class="col-sm-9">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Currencies exchange rates</h4>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Image</th>
                                    <th>Currency</th>
                                    <th>Code</th>
                                    <th>Buying (Taka)</th>
                                    <th>Selling (Taka)</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $exchanges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exchange): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $currency = DB::table('currencies')->find($exchange->currency_id);
                                    ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><img src="<?php echo e($currency->flag); ?>"></td>
                                        <td><?php echo e($currency->name); ?> (<?php echo e($currency->symbol); ?>)</td>
                                        <td><?php echo e($currency->code); ?></td>
                                        <td><?php echo e($exchange->buying_rate); ?></td>
                                        <td><?php echo e($exchange->selling_rate); ?></td>
                                        <td class="d-flex gap-1">
                                            <form action="<?php echo e(route('exchange_rate.edit', $exchange->id)); ?>" method="GET">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-sm btn-warning"><i
                                                        class="fa-solid fa-pen-to-square"></i></button>
                                            </form>
                                            <?php if(!isset($editExchange)): ?>
                                                <a href="<?php echo e(route('exchange_rate.destroy', $exchange->id)); ?>"
                                                    class="btn btn-sm btn-danger"
                                                    onclick="return confirm('Are you sure?')"><i
                                                        class="fa-solid fa-trash"></i></a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Add or Edit form -->
        <div class="col-sm-3">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title"><?php echo e(isset($editExchange) ? 'Update exchange rate' : 'Add exchange rate'); ?></h4>
                            <hr>
                            <form
                                action="<?php echo e(isset($editExchange) ? route('exchange_rate.update', $editExchange->id) : route('exchange_rate.store')); ?>"
                                method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="currency">Currency</label>
                                    <?php if(isset($editExchange)): ?>
                                        <?php
                                            $editExchangeCurrency = DB::table('currencies')->find(
                                                $editExchange->currency_id,
                                            );
                                        ?>
                                        <select name="currency_id" class="form-control">
                                            <option selected disabled><?php echo e($editExchangeCurrency->name); ?>

                                                (<?php echo e($editExchangeCurrency->symbol); ?>) - <?php echo e($editExchangeCurrency->code); ?>

                                            </option>
                                        </select>
                                    <?php else: ?>
                                        <select name="currency_id" class="form-control">
                                            <option selected disabled>Select Currency</option>
                                            <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($currency->id); ?>"
                                                    <?php echo e(isset($editExchange) && $editExchange->currency_id == $currency->id ? 'selected' : ''); ?>>
                                                    <?php echo e($currency->name); ?> (<?php echo e($currency->symbol); ?>) -
                                                    <?php echo e($currency->code); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="buying">Buying Rate</label>
                                    <input type="text" name="buying_rate" class="form-control" id="buying"
                                        value="<?php echo e(isset($editExchange) ? $editExchange->buying_rate : ''); ?>"
                                        placeholder="">
                                </div>
                                <div class="form-group">
                                    <label for="selling">Selling Rate</label>
                                    <input type="text" name="selling_rate" class="form-control" id="selling"
                                        value="<?php echo e(isset($editExchange) ? $editExchange->selling_rate : ''); ?>"
                                        placeholder="">
                                </div>
                                <?php if(isset($editExchange)): ?>
                                    <div class="d-flex">
                                        <button type="submit"
                                            class="btn btn-sm btn-primary w-50"><?php echo e(isset($editExchange) ? 'Update' : 'Save'); ?></button>
                                        <a href="<?php echo e(route('exchange_rate')); ?>"
                                            class="btn btn-sm btn-danger w-50 ms-2">Cancel</a>
                                    </div>
                                <?php else: ?>
                                    <button type="submit"
                                        class="btn btn-sm btn-success w-100"><?php echo e(isset($editExchange) ? 'Update' : 'Save'); ?></button>
                                <?php endif; ?>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('ui.backend.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\currencywithreact\resources\views/ui/backend/pages/exchang-rate.blade.php ENDPATH**/ ?>